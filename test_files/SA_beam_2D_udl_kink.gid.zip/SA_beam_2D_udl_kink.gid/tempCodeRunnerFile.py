e in model_part.Nodes:
        #     disp = node.GetSolutionStepValue(KratosMultiphysics.DISPLACEMENT)
        #     rot = node.GetSolutionStepValue(KratosMultiphysics.ROTATION)
        #     print(f"{node.Id:<6}{node.X:<8.2f}{disp[1]:>+16.6e}{rot[2]:>+16.6e}")
        